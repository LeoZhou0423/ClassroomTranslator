// sherpa-onnx/csrc/ascend/utils.h
//
// Copyright (c)  2025  Xiaomi Corporation

#ifndef SHERPA_ONNX_CSRC_ASCEND_UTILS_H_
#define SHERPA_ONNX_CSRC_ASCEND_UTILS_H_

#include <memory>
#include <string>
#include <vector>

#include "acl/acl.h"

namespace sherpa_onnx {

class Acl {
 public:
  Acl();
  ~Acl();

  Acl(const Acl &) = delete;
  Acl &operator=(const Acl &) = delete;

  Acl(Acl &&) = delete;
  Acl &operator=(Acl &&) = delete;

 private:
  bool initialized_ = false;
};

class AclContext {
 public:
  explicit AclContext(int32_t device_id);

  ~AclContext();

  AclContext(const AclContext &) = delete;
  AclContext &operator=(const AclContext &) = delete;

  AclContext(AclContext &&) = delete;
  AclContext &operator=(AclContext &&) = delete;

  aclrtContext Get() const;
  operator aclrtContext() { return context_; }

 private:
  aclrtContext context_ = nullptr;
};

class AclDevicePtr {
 public:
  explicit AclDevicePtr(
      size_t size, aclrtMemMallocPolicy policy = ACL_MEM_MALLOC_HUGE_FIRST);

  ~AclDevicePtr();

  AclDevicePtr(const AclDevicePtr &) = delete;
  AclDevicePtr &operator=(const AclDevicePtr &) = delete;

  AclDevicePtr(AclDevicePtr &&) = delete;
  AclDevicePtr &operator=(AclDevicePtr &&) = delete;

  void *Get() const { return p_; }

  template <typename T>
  T *Get() const {
    return reinterpret_cast<T *>(p_);
  }

  operator void *() { return p_; }

  size_t Size() const { return size_; }

 private:
  void *p_ = nullptr;
  size_t size_ = 0;
};

class AclModelDesc {
 public:
  explicit AclModelDesc(uint32_t model_id);

  ~AclModelDesc();

  AclModelDesc(const AclModelDesc &) = delete;
  AclModelDesc &operator=(const AclModelDesc &) = delete;

  AclModelDesc(AclModelDesc &&) = delete;
  AclModelDesc &operator=(AclModelDesc &&) = delete;

  aclmdlDesc *Get() const { return p_; }
  operator aclmdlDesc *() const { return p_; }

  size_t Size() const { return size_; }

 private:
  aclmdlDesc *p_ = nullptr;
  size_t size_ = 0;
};

class AclModel {
 public:
  explicit AclModel(const std::string &model_path);
  AclModel(const void *model, size_t model_size);
  ~AclModel();

  uint32_t Get() const { return model_id_; }
  operator uint32_t() const { return model_id_; }

  AclModel(const AclModel &) = delete;
  AclModel &operator=(const AclModel &) = delete;

  AclModel(AclModel &&) = delete;
  AclModel &operator=(AclModel &&) = delete;

  std::string GetInfo() const;

  const std::vector<std::string> &GetInputNames() const { return input_names_; }

  const std::vector<std::vector<int64_t>> &GetInputShapes() const {
    return input_shapes_;
  }

  const std::vector<std::string> &GetOutputNames() const {
    return output_names_;
  }

  const std::vector<std::vector<int64_t>> &GetOutputShapes() const {
    return output_shapes_;
  }

 private:
  void Init();
  void InitInputNames();
  void InitInputShapes();

  void InitOutputNames();
  void InitOutputShapes();

 private:
  uint32_t model_id_ = 0;
  std::unique_ptr<AclModelDesc> desc_;

  std::vector<std::string> input_names_;
  std::vector<std::vector<int64_t>> input_shapes_;

  std::vector<std::string> output_names_;
  std::vector<std::vector<int64_t>> output_shapes_;
};

class AclMdlDataset {
 public:
  AclMdlDataset();
  ~AclMdlDataset();

  AclMdlDataset(const AclMdlDataset &) = delete;
  AclMdlDataset &operator=(const AclMdlDataset &) = delete;

  AclMdlDataset(AclMdlDataset &&) = delete;
  AclMdlDataset &operator=(AclMdlDataset &&) = delete;

  void AddBuffer(aclDataBuffer *buffer) const;
  void SetTensorDesc(aclTensorDesc *tensor_desc, size_t index) const;

  aclmdlDataset *Get() const { return p_; }
  operator aclmdlDataset *() const { return p_; }

 private:
  aclmdlDataset *p_ = nullptr;
};

class AclDataBuffer {
 public:
  AclDataBuffer(void *data, size_t size);
  ~AclDataBuffer();

  AclDataBuffer(const AclDataBuffer &) = delete;
  AclDataBuffer &operator=(const AclDataBuffer &) = delete;

  AclDataBuffer(AclDataBuffer &&other) {
    p_ = other.p_;
    other.p_ = nullptr;
  }
  AclDataBuffer &operator=(AclDataBuffer &&other) {
    if (this == &other) {
      return *this;
    }

    Release();

    p_ = other.p_;
    other.p_ = nullptr;
    return *this;
  }

  void Release();

  aclDataBuffer *Get() const { return p_; }
  operator aclDataBuffer *() const { return p_; }

 private:
  aclDataBuffer *p_ = nullptr;
};

class AclTensorDesc {
 public:
  AclTensorDesc(aclDataType data_type, int num_dims, const int64_t *dims,
                aclFormat format);
  ~AclTensorDesc();

  AclTensorDesc(const AclTensorDesc &) = delete;
  AclTensorDesc &operator=(const AclTensorDesc &) = delete;

  AclTensorDesc(AclTensorDesc &&) = delete;
  AclTensorDesc &operator=(AclTensorDesc &&) = delete;

  aclTensorDesc *Get() const { return p_; }
  operator aclTensorDesc *() const { return p_; }

 private:
  aclTensorDesc *p_ = nullptr;
};

}  // namespace sherpa_onnx

#endif  // SHERPA_ONNX_CSRC_ASCEND_UTILS_H_
