// sherpa-onnx/c-api/cxx-api.cc
//
// Copyright (c)  2024  Xiaomi Corporation
#include "sherpa-onnx/c-api/cxx-api.h"

#include <algorithm>
#include <cstring>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "nlohmann/json.hpp"

namespace sherpa_onnx::cxx {

static void FillSpeechDenoiserModelConfig(
    const OfflineSpeechDenoiserModelConfig &src,
    SherpaOnnxOfflineSpeechDenoiserModelConfig *dst) {
  memset(dst, 0, sizeof(*dst));
  dst->gtcrn.model = src.gtcrn.model.c_str();
  dst->dpdfnet.model = src.dpdfnet.model.c_str();
  dst->dpdfnet.attenuation_limit_db = src.dpdfnet.attenuation_limit_db;
  dst->num_threads = src.num_threads;
  dst->provider = src.provider.c_str();
  dst->debug = src.debug;
}

Wave ReadWave(const std::string &filename) {
  auto p = SherpaOnnxReadWave(filename.c_str());

  Wave ans;
  if (p) {
    ans.samples.resize(p->num_samples);

    std::copy(p->samples, p->samples + p->num_samples, ans.samples.data());

    ans.sample_rate = p->sample_rate;
    SherpaOnnxFreeWave(p);
  }

  return ans;
}

bool WriteWave(const std::string &filename, const Wave &wave) {
  return SherpaOnnxWriteWave(wave.samples.data(), wave.samples.size(),
                             wave.sample_rate, filename.c_str());
}

OnlineStream::OnlineStream(const SherpaOnnxOnlineStream *p)
    : MoveOnly<OnlineStream, SherpaOnnxOnlineStream>(p) {}

void OnlineStream::Destroy(const SherpaOnnxOnlineStream *p) const {
  SherpaOnnxDestroyOnlineStream(p);
}

void OnlineStream::AcceptWaveform(int32_t sample_rate, const float *samples,
                                  int32_t n) const {
  SherpaOnnxOnlineStreamAcceptWaveform(p_, sample_rate, samples, n);
}

void OnlineStream::InputFinished() const {
  SherpaOnnxOnlineStreamInputFinished(p_);
}

void OnlineStream::SetOption(const char *key, const char *value) const {
  SherpaOnnxOnlineStreamSetOption(p_, key, value);
}

const char *OnlineStream::GetOption(const char *key) const {
  return SherpaOnnxOnlineStreamGetOption(p_, key);
}

int32_t OnlineStream::HasOption(const char *key) const {
  return SherpaOnnxOnlineStreamHasOption(p_, key);
}

OnlineRecognizer OnlineRecognizer::Create(
    const OnlineRecognizerConfig &config) {
  struct SherpaOnnxOnlineRecognizerConfig c;
  memset(&c, 0, sizeof(c));

  c.feat_config.sample_rate = config.feat_config.sample_rate;
  c.feat_config.feature_dim = config.feat_config.feature_dim;

  c.model_config.transducer.encoder =
      config.model_config.transducer.encoder.c_str();
  c.model_config.transducer.decoder =
      config.model_config.transducer.decoder.c_str();
  c.model_config.transducer.joiner =
      config.model_config.transducer.joiner.c_str();

  c.model_config.paraformer.encoder =
      config.model_config.paraformer.encoder.c_str();
  c.model_config.paraformer.decoder =
      config.model_config.paraformer.decoder.c_str();

  c.model_config.zipformer2_ctc.model =
      config.model_config.zipformer2_ctc.model.c_str();

  c.model_config.nemo_ctc.model = config.model_config.nemo_ctc.model.c_str();
  c.model_config.t_one_ctc.model = config.model_config.t_one_ctc.model.c_str();

  c.model_config.tokens = config.model_config.tokens.c_str();
  c.model_config.num_threads = config.model_config.num_threads;
  c.model_config.provider = config.model_config.provider.c_str();
  c.model_config.debug = config.model_config.debug;
  c.model_config.model_type = config.model_config.model_type.c_str();
  c.model_config.modeling_unit = config.model_config.modeling_unit.c_str();
  c.model_config.bpe_vocab = config.model_config.bpe_vocab.c_str();
  c.model_config.tokens_buf = config.model_config.tokens_buf.c_str();
  c.model_config.tokens_buf_size = config.model_config.tokens_buf.size();

  c.decoding_method = config.decoding_method.c_str();
  c.max_active_paths = config.max_active_paths;
  c.enable_endpoint = config.enable_endpoint;
  c.rule1_min_trailing_silence = config.rule1_min_trailing_silence;
  c.rule2_min_trailing_silence = config.rule2_min_trailing_silence;
  c.rule3_min_utterance_length = config.rule3_min_utterance_length;
  c.hotwords_file = config.hotwords_file.c_str();
  c.hotwords_score = config.hotwords_score;

  c.ctc_fst_decoder_config.graph = config.ctc_fst_decoder_config.graph.c_str();
  c.ctc_fst_decoder_config.max_active =
      config.ctc_fst_decoder_config.max_active;

  c.rule_fsts = config.rule_fsts.c_str();
  c.rule_fars = config.rule_fars.c_str();

  c.blank_penalty = config.blank_penalty;

  c.hotwords_buf = config.hotwords_buf.c_str();
  c.hotwords_buf_size = config.hotwords_buf.size();

  c.hr.lexicon = config.hr.lexicon.c_str();
  c.hr.rule_fsts = config.hr.rule_fsts.c_str();

  auto p = SherpaOnnxCreateOnlineRecognizer(&c);
  return OnlineRecognizer(p);
}

OnlineRecognizer::OnlineRecognizer(const SherpaOnnxOnlineRecognizer *p)
    : MoveOnly<OnlineRecognizer, SherpaOnnxOnlineRecognizer>(p) {}

void OnlineRecognizer::Destroy(const SherpaOnnxOnlineRecognizer *p) const {
  SherpaOnnxDestroyOnlineRecognizer(p);
}

OnlineStream OnlineRecognizer::CreateStream() const {
  auto s = SherpaOnnxCreateOnlineStream(p_);
  return OnlineStream{s};
}

OnlineStream OnlineRecognizer::CreateStream(const std::string &hotwords) const {
  auto s = SherpaOnnxCreateOnlineStreamWithHotwords(p_, hotwords.c_str());
  return OnlineStream{s};
}

bool OnlineRecognizer::IsReady(const OnlineStream *s) const {
  return SherpaOnnxIsOnlineStreamReady(p_, s->Get());
}

void OnlineRecognizer::Decode(const OnlineStream *s) const {
  SherpaOnnxDecodeOnlineStream(p_, s->Get());
}

void OnlineRecognizer::Reset(const OnlineStream *s) const {
  SherpaOnnxOnlineStreamReset(p_, s->Get());
}

bool OnlineRecognizer::IsEndpoint(const OnlineStream *s) const {
  return SherpaOnnxOnlineStreamIsEndpoint(p_, s->Get());
}

void OnlineRecognizer::Decode(const OnlineStream *ss, int32_t n) const {
  if (n <= 0) {
    return;
  }

  std::vector<const SherpaOnnxOnlineStream *> streams(n);
  for (int32_t i = 0; i != n; ++i) {
    streams[i] = ss[i].Get();
  }

  SherpaOnnxDecodeMultipleOnlineStreams(p_, streams.data(), n);
}

OnlineRecognizerResult OnlineRecognizer::GetResult(
    const OnlineStream *s) const {
  auto r = SherpaOnnxGetOnlineStreamResult(p_, s->Get());

  OnlineRecognizerResult ans;
  if (!r) {
    return ans;
  }

  ans.text = r->text;

  ans.tokens.resize(r->count);
  for (int32_t i = 0; i != r->count; ++i) {
    ans.tokens[i] = r->tokens_arr[i];
  }

  if (r->timestamps) {
    ans.timestamps.resize(r->count);
    std::copy(r->timestamps, r->timestamps + r->count, ans.timestamps.data());
  }

  ans.json = r->json;

  SherpaOnnxDestroyOnlineRecognizerResult(r);

  return ans;
}

// ============================================================================
// Non-streaming ASR
// ============================================================================
OfflineStream::OfflineStream(const SherpaOnnxOfflineStream *p)
    : MoveOnly<OfflineStream, SherpaOnnxOfflineStream>(p) {}

void OfflineStream::Destroy(const SherpaOnnxOfflineStream *p) const {
  SherpaOnnxDestroyOfflineStream(p);
}

void OfflineStream::AcceptWaveform(int32_t sample_rate, const float *samples,
                                   int32_t n) const {
  SherpaOnnxAcceptWaveformOffline(p_, sample_rate, samples, n);
}

void OfflineStream::SetOption(const char *key, const char *value) const {
  SherpaOnnxOfflineStreamSetOption(p_, key, value);
}

const char *OfflineStream::GetOption(const char *key) const {
  return SherpaOnnxOfflineStreamGetOption(p_, key);
}

int32_t OfflineStream::HasOption(const char *key) const {
  return SherpaOnnxOfflineStreamHasOption(p_, key);
}

static SherpaOnnxOfflineRecognizerConfig Convert(
    const OfflineRecognizerConfig &config) {
  struct SherpaOnnxOfflineRecognizerConfig c;
  memset(&c, 0, sizeof(c));

  c.feat_config.sample_rate = config.feat_config.sample_rate;
  c.feat_config.feature_dim = config.feat_config.feature_dim;
  c.model_config.transducer.encoder =
      config.model_config.transducer.encoder.c_str();
  c.model_config.transducer.decoder =
      config.model_config.transducer.decoder.c_str();
  c.model_config.transducer.joiner =
      config.model_config.transducer.joiner.c_str();

  c.model_config.paraformer.model =
      config.model_config.paraformer.model.c_str();

  c.model_config.nemo_ctc.model = config.model_config.nemo_ctc.model.c_str();

  c.model_config.whisper.encoder = config.model_config.whisper.encoder.c_str();
  c.model_config.whisper.decoder = config.model_config.whisper.decoder.c_str();
  c.model_config.whisper.language =
      config.model_config.whisper.language.c_str();
  c.model_config.whisper.task = config.model_config.whisper.task.c_str();
  c.model_config.whisper.tail_paddings =
      config.model_config.whisper.tail_paddings;
  c.model_config.whisper.enable_token_timestamps =
      config.model_config.whisper.enable_token_timestamps;
  c.model_config.whisper.enable_segment_timestamps =
      config.model_config.whisper.enable_segment_timestamps;

  c.model_config.tdnn.model = config.model_config.tdnn.model.c_str();

  c.model_config.tokens = config.model_config.tokens.c_str();
  c.model_config.num_threads = config.model_config.num_threads;
  c.model_config.debug = config.model_config.debug;
  c.model_config.provider = config.model_config.provider.c_str();
  c.model_config.model_type = config.model_config.model_type.c_str();
  c.model_config.modeling_unit = config.model_config.modeling_unit.c_str();
  c.model_config.bpe_vocab = config.model_config.bpe_vocab.c_str();
  c.model_config.telespeech_ctc = config.model_config.telespeech_ctc.c_str();

  c.model_config.sense_voice.model =
      config.model_config.sense_voice.model.c_str();
  c.model_config.sense_voice.language =
      config.model_config.sense_voice.language.c_str();
  c.model_config.sense_voice.use_itn = config.model_config.sense_voice.use_itn;

  c.model_config.moonshine.preprocessor =
      config.model_config.moonshine.preprocessor.c_str();
  c.model_config.moonshine.encoder =
      config.model_config.moonshine.encoder.c_str();
  c.model_config.moonshine.uncached_decoder =
      config.model_config.moonshine.uncached_decoder.c_str();
  c.model_config.moonshine.cached_decoder =
      config.model_config.moonshine.cached_decoder.c_str();
  c.model_config.moonshine.merged_decoder =
      config.model_config.moonshine.merged_decoder.c_str();

  c.model_config.fire_red_asr.encoder =
      config.model_config.fire_red_asr.encoder.c_str();
  c.model_config.fire_red_asr.decoder =
      config.model_config.fire_red_asr.decoder.c_str();

  c.model_config.dolphin.model = config.model_config.dolphin.model.c_str();

  c.model_config.zipformer_ctc.model =
      config.model_config.zipformer_ctc.model.c_str();

  c.model_config.canary.encoder = config.model_config.canary.encoder.c_str();
  c.model_config.canary.decoder = config.model_config.canary.decoder.c_str();
  c.model_config.canary.src_lang = config.model_config.canary.src_lang.c_str();
  c.model_config.canary.tgt_lang = config.model_config.canary.tgt_lang.c_str();
  c.model_config.canary.use_pnc = config.model_config.canary.use_pnc;

  c.model_config.cohere_transcribe.encoder =
      config.model_config.cohere_transcribe.encoder.c_str();
  c.model_config.cohere_transcribe.decoder =
      config.model_config.cohere_transcribe.decoder.c_str();
  c.model_config.cohere_transcribe.language =
      config.model_config.cohere_transcribe.language.c_str();
  c.model_config.cohere_transcribe.use_punct =
      config.model_config.cohere_transcribe.use_punct;
  c.model_config.cohere_transcribe.use_itn =
      config.model_config.cohere_transcribe.use_itn;

  c.model_config.wenet_ctc.model = config.model_config.wenet_ctc.model.c_str();

  c.model_config.omnilingual.model =
      config.model_config.omnilingual.model.c_str();

  c.model_config.funasr_nano.encoder_adaptor =
      config.model_config.funasr_nano.encoder_adaptor.c_str();
  c.model_config.funasr_nano.llm = config.model_config.funasr_nano.llm.c_str();
  c.model_config.funasr_nano.embedding =
      config.model_config.funasr_nano.embedding.c_str();
  c.model_config.funasr_nano.tokenizer =
      config.model_config.funasr_nano.tokenizer.c_str();
  c.model_config.funasr_nano.system_prompt =
      config.model_config.funasr_nano.system_prompt.c_str();
  c.model_config.funasr_nano.user_prompt =
      config.model_config.funasr_nano.user_prompt.c_str();
  c.model_config.funasr_nano.max_new_tokens =
      config.model_config.funasr_nano.max_new_tokens;
  c.model_config.funasr_nano.temperature =
      config.model_config.funasr_nano.temperature;
  c.model_config.funasr_nano.top_p = config.model_config.funasr_nano.top_p;
  c.model_config.funasr_nano.seed = config.model_config.funasr_nano.seed;
  c.model_config.funasr_nano.language =
      config.model_config.funasr_nano.language.c_str();
  c.model_config.funasr_nano.itn = config.model_config.funasr_nano.itn ? 1 : 0;
  c.model_config.funasr_nano.hotwords =
      config.model_config.funasr_nano.hotwords.c_str();

  c.model_config.qwen3_asr.conv_frontend =
      config.model_config.qwen3_asr.conv_frontend.c_str();
  c.model_config.qwen3_asr.encoder =
      config.model_config.qwen3_asr.encoder.c_str();
  c.model_config.qwen3_asr.decoder =
      config.model_config.qwen3_asr.decoder.c_str();
  c.model_config.qwen3_asr.tokenizer =
      config.model_config.qwen3_asr.tokenizer.c_str();
  c.model_config.qwen3_asr.hotwords =
      config.model_config.qwen3_asr.hotwords.c_str();
  c.model_config.qwen3_asr.max_total_len =
      config.model_config.qwen3_asr.max_total_len;
  c.model_config.qwen3_asr.max_new_tokens =
      config.model_config.qwen3_asr.max_new_tokens;
  c.model_config.qwen3_asr.temperature =
      config.model_config.qwen3_asr.temperature;
  c.model_config.qwen3_asr.top_p = config.model_config.qwen3_asr.top_p;
  c.model_config.qwen3_asr.seed = config.model_config.qwen3_asr.seed;

  c.model_config.medasr.model = config.model_config.medasr.model.c_str();

  c.model_config.fire_red_asr_ctc.model =
      config.model_config.fire_red_asr_ctc.model.c_str();

  c.lm_config.model = config.lm_config.model.c_str();
  c.lm_config.scale = config.lm_config.scale;

  c.decoding_method = config.decoding_method.c_str();
  c.max_active_paths = config.max_active_paths;
  c.hotwords_file = config.hotwords_file.c_str();
  c.hotwords_score = config.hotwords_score;

  c.rule_fsts = config.rule_fsts.c_str();
  c.rule_fars = config.rule_fars.c_str();

  c.blank_penalty = config.blank_penalty;

  c.hr.lexicon = config.hr.lexicon.c_str();
  c.hr.rule_fsts = config.hr.rule_fsts.c_str();

  return c;
}

OfflineRecognizer OfflineRecognizer::Create(
    const OfflineRecognizerConfig &config) {
  auto c = Convert(config);

  auto p = SherpaOnnxCreateOfflineRecognizer(&c);
  return OfflineRecognizer(p);
}

void OfflineRecognizer::SetConfig(const OfflineRecognizerConfig &config) const {
  auto c = Convert(config);
  SherpaOnnxOfflineRecognizerSetConfig(p_, &c);
}

OfflineRecognizer::OfflineRecognizer(const SherpaOnnxOfflineRecognizer *p)
    : MoveOnly<OfflineRecognizer, SherpaOnnxOfflineRecognizer>(p) {}

void OfflineRecognizer::Destroy(const SherpaOnnxOfflineRecognizer *p) const {
  SherpaOnnxDestroyOfflineRecognizer(p);
}

OfflineStream OfflineRecognizer::CreateStream() const {
  auto s = SherpaOnnxCreateOfflineStream(p_);
  return OfflineStream{s};
}

OfflineStream OfflineRecognizer::CreateStream(
    const std::string &hotwords) const {
  auto s = SherpaOnnxCreateOfflineStreamWithHotwords(p_, hotwords.c_str());
  return OfflineStream{s};
}

void OfflineRecognizer::Decode(const OfflineStream *s) const {
  SherpaOnnxDecodeOfflineStream(p_, s->Get());
}

void OfflineRecognizer::Decode(const OfflineStream *ss, int32_t n) const {
  if (n <= 0) {
    return;
  }

  std::vector<const SherpaOnnxOfflineStream *> streams(n);
  for (int32_t i = 0; i != n; ++i) {
    streams[i] = ss[i].Get();
  }

  SherpaOnnxDecodeMultipleOfflineStreams(p_, streams.data(), n);
}

OfflineRecognizerResult OfflineRecognizer::GetResult(
    const OfflineStream *s) const {
  auto r = SherpaOnnxGetOfflineStreamResult(s->Get());

  OfflineRecognizerResult ans;
  if (r) {
    ans.text = r->text;

    if (r->timestamps) {
      ans.timestamps.resize(r->count);
      std::copy(r->timestamps, r->timestamps + r->count, ans.timestamps.data());
    }

    ans.tokens.resize(r->count);
    for (int32_t i = 0; i != r->count; ++i) {
      ans.tokens[i] = r->tokens_arr[i];
    }

    ans.json = r->json;
    ans.lang = r->lang ? r->lang : "";
    ans.emotion = r->emotion ? r->emotion : "";
    ans.event = r->event ? r->event : "";

    if (r->durations) {
      ans.durations.resize(r->count);
      std::copy(r->durations, r->durations + r->count, ans.durations.data());
    }
  }

  SherpaOnnxDestroyOfflineRecognizerResult(r);

  return ans;
}

std::shared_ptr<OfflineRecognizerResult> OfflineRecognizer::GetResultPtr(
    const OfflineStream *s) const {
  auto r = GetResult(s);
  return std::make_shared<OfflineRecognizerResult>(r);
}

OfflineTts OfflineTts::Create(const OfflineTtsConfig &config) {
  struct SherpaOnnxOfflineTtsConfig c;
  memset(&c, 0, sizeof(c));

  c.model.vits.model = config.model.vits.model.c_str();
  c.model.vits.lexicon = config.model.vits.lexicon.c_str();
  c.model.vits.tokens = config.model.vits.tokens.c_str();
  c.model.vits.data_dir = config.model.vits.data_dir.c_str();
  c.model.vits.noise_scale = config.model.vits.noise_scale;
  c.model.vits.noise_scale_w = config.model.vits.noise_scale_w;
  c.model.vits.length_scale = config.model.vits.length_scale;

  c.model.matcha.acoustic_model = config.model.matcha.acoustic_model.c_str();
  c.model.matcha.vocoder = config.model.matcha.vocoder.c_str();
  c.model.matcha.lexicon = config.model.matcha.lexicon.c_str();
  c.model.matcha.tokens = config.model.matcha.tokens.c_str();
  c.model.matcha.data_dir = config.model.matcha.data_dir.c_str();
  c.model.matcha.noise_scale = config.model.matcha.noise_scale;
  c.model.matcha.length_scale = config.model.matcha.length_scale;

  c.model.kokoro.model = config.model.kokoro.model.c_str();
  c.model.kokoro.voices = config.model.kokoro.voices.c_str();
  c.model.kokoro.tokens = config.model.kokoro.tokens.c_str();
  c.model.kokoro.data_dir = config.model.kokoro.data_dir.c_str();
  c.model.kokoro.length_scale = config.model.kokoro.length_scale;
  c.model.kokoro.lexicon = config.model.kokoro.lexicon.c_str();
  c.model.kokoro.lang = config.model.kokoro.lang.c_str();

  c.model.kitten.model = config.model.kitten.model.c_str();
  c.model.kitten.voices = config.model.kitten.voices.c_str();
  c.model.kitten.tokens = config.model.kitten.tokens.c_str();
  c.model.kitten.data_dir = config.model.kitten.data_dir.c_str();
  c.model.kitten.length_scale = config.model.kitten.length_scale;

  c.model.zipvoice.tokens = config.model.zipvoice.tokens.c_str();
  c.model.zipvoice.encoder = config.model.zipvoice.encoder.c_str();
  c.model.zipvoice.decoder = config.model.zipvoice.decoder.c_str();
  c.model.zipvoice.vocoder = config.model.zipvoice.vocoder.c_str();
  c.model.zipvoice.data_dir = config.model.zipvoice.data_dir.c_str();
  c.model.zipvoice.lexicon = config.model.zipvoice.lexicon.c_str();
  c.model.zipvoice.feat_scale = config.model.zipvoice.feat_scale;
  c.model.zipvoice.t_shift = config.model.zipvoice.t_shift;
  c.model.zipvoice.target_rms = config.model.zipvoice.target_rms;
  c.model.zipvoice.guidance_scale = config.model.zipvoice.guidance_scale;

  c.model.pocket.lm_flow = config.model.pocket.lm_flow.c_str();
  c.model.pocket.lm_main = config.model.pocket.lm_main.c_str();
  c.model.pocket.encoder = config.model.pocket.encoder.c_str();
  c.model.pocket.decoder = config.model.pocket.decoder.c_str();
  c.model.pocket.text_conditioner =
      config.model.pocket.text_conditioner.c_str();

  c.model.pocket.vocab_json = config.model.pocket.vocab_json.c_str();

  c.model.pocket.token_scores_json =
      config.model.pocket.token_scores_json.c_str();

  c.model.pocket.voice_embedding_cache_capacity =
      config.model.pocket.voice_embedding_cache_capacity;

  c.model.supertonic.duration_predictor =
      config.model.supertonic.duration_predictor.c_str();
  c.model.supertonic.text_encoder =
      config.model.supertonic.text_encoder.c_str();
  c.model.supertonic.vector_estimator =
      config.model.supertonic.vector_estimator.c_str();
  c.model.supertonic.vocoder = config.model.supertonic.vocoder.c_str();
  c.model.supertonic.tts_json = config.model.supertonic.tts_json.c_str();
  c.model.supertonic.unicode_indexer =
      config.model.supertonic.unicode_indexer.c_str();
  c.model.supertonic.voice_style = config.model.supertonic.voice_style.c_str();

  c.model.num_threads = config.model.num_threads;
  c.model.debug = config.model.debug;
  c.model.provider = config.model.provider.c_str();

  c.rule_fsts = config.rule_fsts.c_str();
  c.max_num_sentences = config.max_num_sentences;
  c.silence_scale = config.silence_scale;
  c.rule_fars = config.rule_fars.c_str();

  auto p = SherpaOnnxCreateOfflineTts(&c);
  return OfflineTts(p);
}

OfflineTts::OfflineTts(const SherpaOnnxOfflineTts *p)
    : MoveOnly<OfflineTts, SherpaOnnxOfflineTts>(p) {}

void OfflineTts::Destroy(const SherpaOnnxOfflineTts *p) const {
  SherpaOnnxDestroyOfflineTts(p);
}

int32_t OfflineTts::SampleRate() const {
  return SherpaOnnxOfflineTtsSampleRate(p_);
}

int32_t OfflineTts::NumSpeakers() const {
  return SherpaOnnxOfflineTtsNumSpeakers(p_);
}

GeneratedAudio OfflineTts::Generate(const std::string &text,
                                    int32_t sid /*= 0*/, float speed /*= 1.0*/,
                                    OfflineTtsCallback callback /*= nullptr*/,
                                    void *arg /*= nullptr*/) const {
  SherpaOnnxGenerationConfig c;
  memset(&c, 0, sizeof(c));
  c.sid = sid;
  c.speed = speed;

  const SherpaOnnxGeneratedAudio *audio =
      SherpaOnnxOfflineTtsGenerateWithConfig(p_, text.c_str(), &c, callback,
                                             arg);

  GeneratedAudio ans;

  if (!audio) {
    return ans;
  }

  ans.samples = std::vector<float>{audio->samples, audio->samples + audio->n};
  ans.sample_rate = audio->sample_rate;

  SherpaOnnxDestroyOfflineTtsGeneratedAudio(audio);
  return ans;
}

GeneratedAudio OfflineTts::Generate(const std::string &text,
                                    const GenerationConfig &config,
                                    OfflineTtsCallback callback /*= nullptr*/,
                                    void *arg /*= nullptr*/) const {
  SherpaOnnxGenerationConfig c;
  memset(&c, 0, sizeof(c));

  c.silence_scale = config.silence_scale;
  c.speed = config.speed;
  c.sid = config.sid;
  c.reference_audio = config.reference_audio.data();
  c.reference_audio_len = config.reference_audio.size();
  c.reference_sample_rate = config.reference_sample_rate;
  c.reference_text = config.reference_text.c_str();
  c.num_steps = config.num_steps;

  nlohmann::json j = config.extra;
  std::string s = j.dump();
  c.extra = s.c_str();

  const SherpaOnnxGeneratedAudio *audio =
      SherpaOnnxOfflineTtsGenerateWithConfig(p_, text.c_str(), &c, callback,
                                             arg);
  GeneratedAudio ans;

  if (!audio) {
    return ans;
  }

  ans.samples = std::vector<float>{audio->samples, audio->samples + audio->n};
  ans.sample_rate = audio->sample_rate;
  SherpaOnnxDestroyOfflineTtsGeneratedAudio(audio);
  return ans;
}

std::shared_ptr<GeneratedAudio> OfflineTts::Generate2(
    const std::string &text, int32_t sid /*= 0*/, float speed /*= 1.0*/,
    OfflineTtsCallback callback /*= nullptr*/, void *arg /*= nullptr*/) const {
  auto audio = Generate(text, sid, speed, callback, arg);

  GeneratedAudio *ans = new GeneratedAudio;
  ans->samples = std::move(audio.samples);
  ans->sample_rate = audio.sample_rate;

  return std::shared_ptr<GeneratedAudio>(ans);
}

std::shared_ptr<GeneratedAudio> OfflineTts::Generate2(
    const std::string &text, const GenerationConfig &config,
    OfflineTtsCallback callback /*= nullptr*/, void *arg /*= nullptr*/) const {
  auto audio = Generate(text, config, callback, arg);

  GeneratedAudio *ans = new GeneratedAudio;
  ans->samples = std::move(audio.samples);
  ans->sample_rate = audio.sample_rate;

  return std::shared_ptr<GeneratedAudio>(ans);
}

KeywordSpotter KeywordSpotter::Create(const KeywordSpotterConfig &config) {
  struct SherpaOnnxKeywordSpotterConfig c;
  memset(&c, 0, sizeof(c));

  c.feat_config.sample_rate = config.feat_config.sample_rate;

  c.model_config.transducer.encoder =
      config.model_config.transducer.encoder.c_str();
  c.model_config.transducer.decoder =
      config.model_config.transducer.decoder.c_str();
  c.model_config.transducer.joiner =
      config.model_config.transducer.joiner.c_str();
  c.feat_config.feature_dim = config.feat_config.feature_dim;

  c.model_config.paraformer.encoder =
      config.model_config.paraformer.encoder.c_str();
  c.model_config.paraformer.decoder =
      config.model_config.paraformer.decoder.c_str();

  c.model_config.zipformer2_ctc.model =
      config.model_config.zipformer2_ctc.model.c_str();

  c.model_config.nemo_ctc.model = config.model_config.nemo_ctc.model.c_str();

  c.model_config.tokens = config.model_config.tokens.c_str();
  c.model_config.num_threads = config.model_config.num_threads;
  c.model_config.provider = config.model_config.provider.c_str();
  c.model_config.debug = config.model_config.debug;
  c.model_config.model_type = config.model_config.model_type.c_str();
  c.model_config.modeling_unit = config.model_config.modeling_unit.c_str();
  c.model_config.bpe_vocab = config.model_config.bpe_vocab.c_str();
  c.model_config.tokens_buf = config.model_config.tokens_buf.c_str();
  c.model_config.tokens_buf_size = config.model_config.tokens_buf.size();

  c.max_active_paths = config.max_active_paths;
  c.num_trailing_blanks = config.num_trailing_blanks;
  c.keywords_score = config.keywords_score;
  c.keywords_threshold = config.keywords_threshold;
  c.keywords_file = config.keywords_file.c_str();
  c.keywords_buf = config.keywords_buf.c_str();
  c.keywords_buf_size = static_cast<int32_t>(config.keywords_buf.size());

  auto p = SherpaOnnxCreateKeywordSpotter(&c);
  return KeywordSpotter(p);
}

KeywordSpotter::KeywordSpotter(const SherpaOnnxKeywordSpotter *p)
    : MoveOnly<KeywordSpotter, SherpaOnnxKeywordSpotter>(p) {}

void KeywordSpotter::Destroy(const SherpaOnnxKeywordSpotter *p) const {
  SherpaOnnxDestroyKeywordSpotter(p);
}

OnlineStream KeywordSpotter::CreateStream() const {
  auto s = SherpaOnnxCreateKeywordStream(p_);
  return OnlineStream{s};
}

OnlineStream KeywordSpotter::CreateStream(const std::string &keywords) const {
  auto s = SherpaOnnxCreateKeywordStreamWithKeywords(p_, keywords.c_str());
  return OnlineStream{s};
}

bool KeywordSpotter::IsReady(const OnlineStream *s) const {
  return SherpaOnnxIsKeywordStreamReady(p_, s->Get());
}

void KeywordSpotter::Decode(const OnlineStream *s) const {
  return SherpaOnnxDecodeKeywordStream(p_, s->Get());
}

void KeywordSpotter::Decode(const OnlineStream *ss, int32_t n) const {
  if (n <= 0) {
    return;
  }

  std::vector<const SherpaOnnxOnlineStream *> streams(n);
  for (int32_t i = 0; i != n; ++i) {
    streams[i] = ss[i].Get();
  }

  SherpaOnnxDecodeMultipleKeywordStreams(p_, streams.data(), n);
}

KeywordResult KeywordSpotter::GetResult(const OnlineStream *s) const {
  auto r = SherpaOnnxGetKeywordResult(p_, s->Get());

  KeywordResult ans;
  if (!r) return ans;

  ans.keyword = r->keyword;

  ans.tokens.resize(r->count);
  for (int32_t i = 0; i < r->count; ++i) {
    ans.tokens[i] = r->tokens_arr[i];
  }

  if (r->timestamps) {
    ans.timestamps.resize(r->count);
    std::copy(r->timestamps, r->timestamps + r->count, ans.timestamps.data());
  }

  ans.start_time = r->start_time;
  ans.json = r->json;

  SherpaOnnxDestroyKeywordResult(r);

  return ans;
}

void KeywordSpotter::Reset(const OnlineStream *s) const {
  SherpaOnnxResetKeywordStream(p_, s->Get());
}

// ============================================================
// For Offline Speech Enhancement
// ============================================================

OfflineSpeechDenoiser OfflineSpeechDenoiser::Create(
    const OfflineSpeechDenoiserConfig &config) {
  struct SherpaOnnxOfflineSpeechDenoiserConfig c;
  FillSpeechDenoiserModelConfig(config.model, &c.model);

  auto p = SherpaOnnxCreateOfflineSpeechDenoiser(&c);

  return OfflineSpeechDenoiser(p);
}

void OfflineSpeechDenoiser::Destroy(
    const SherpaOnnxOfflineSpeechDenoiser *p) const {
  SherpaOnnxDestroyOfflineSpeechDenoiser(p);
}

OfflineSpeechDenoiser::OfflineSpeechDenoiser(
    const SherpaOnnxOfflineSpeechDenoiser *p)
    : MoveOnly<OfflineSpeechDenoiser, SherpaOnnxOfflineSpeechDenoiser>(p) {}

DenoisedAudio OfflineSpeechDenoiser::Run(const float *samples, int32_t n,
                                         int32_t sample_rate) const {
  auto audio = SherpaOnnxOfflineSpeechDenoiserRun(p_, samples, n, sample_rate);
  if (audio == nullptr) {
    return {};
  }

  DenoisedAudio ans;
  ans.samples = {audio->samples, audio->samples + audio->n};
  ans.sample_rate = audio->sample_rate;
  SherpaOnnxDestroyDenoisedAudio(audio);

  return ans;
}

int32_t OfflineSpeechDenoiser::GetSampleRate() const {
  return SherpaOnnxOfflineSpeechDenoiserGetSampleRate(p_);
}

OnlineSpeechDenoiser OnlineSpeechDenoiser::Create(
    const OnlineSpeechDenoiserConfig &config) {
  struct SherpaOnnxOnlineSpeechDenoiserConfig c;
  FillSpeechDenoiserModelConfig(config.model, &c.model);

  auto p = SherpaOnnxCreateOnlineSpeechDenoiser(&c);
  return OnlineSpeechDenoiser(p);
}

void OnlineSpeechDenoiser::Destroy(
    const SherpaOnnxOnlineSpeechDenoiser *p) const {
  SherpaOnnxDestroyOnlineSpeechDenoiser(p);
}

OnlineSpeechDenoiser::OnlineSpeechDenoiser(
    const SherpaOnnxOnlineSpeechDenoiser *p)
    : MoveOnly<OnlineSpeechDenoiser, SherpaOnnxOnlineSpeechDenoiser>(p) {}

DenoisedAudio OnlineSpeechDenoiser::Run(const float *samples, int32_t n,
                                        int32_t sample_rate) const {
  auto audio = SherpaOnnxOnlineSpeechDenoiserRun(p_, samples, n, sample_rate);
  if (audio == nullptr) {
    return {};
  }

  DenoisedAudio ans;
  ans.samples = {audio->samples, audio->samples + audio->n};
  ans.sample_rate = audio->sample_rate;
  SherpaOnnxDestroyDenoisedAudio(audio);
  return ans;
}

DenoisedAudio OnlineSpeechDenoiser::Flush() const {
  auto audio = SherpaOnnxOnlineSpeechDenoiserFlush(p_);
  if (audio == nullptr) {
    return {};
  }

  DenoisedAudio ans;
  ans.samples = {audio->samples, audio->samples + audio->n};
  ans.sample_rate = audio->sample_rate;
  SherpaOnnxDestroyDenoisedAudio(audio);
  return ans;
}

void OnlineSpeechDenoiser::Reset() const {
  SherpaOnnxOnlineSpeechDenoiserReset(p_);
}

int32_t OnlineSpeechDenoiser::GetSampleRate() const {
  return SherpaOnnxOnlineSpeechDenoiserGetSampleRate(p_);
}

int32_t OnlineSpeechDenoiser::GetFrameShiftInSamples() const {
  return SherpaOnnxOnlineSpeechDenoiserGetFrameShiftInSamples(p_);
}

CircularBuffer CircularBuffer::Create(int32_t capacity) {
  auto p = SherpaOnnxCreateCircularBuffer(capacity);
  return CircularBuffer(p);
}

CircularBuffer::CircularBuffer(const SherpaOnnxCircularBuffer *p)
    : MoveOnly<CircularBuffer, SherpaOnnxCircularBuffer>(p) {}

void CircularBuffer::Destroy(const SherpaOnnxCircularBuffer *p) const {
  SherpaOnnxDestroyCircularBuffer(p);
}

void CircularBuffer::Push(const float *samples, int32_t n) const {
  SherpaOnnxCircularBufferPush(p_, samples, n);
}

std::vector<float> CircularBuffer::Get(int32_t start_index, int32_t n) const {
  const float *samples = SherpaOnnxCircularBufferGet(p_, start_index, n);
  if (!samples) return {};

  std::vector<float> ans(n);
  std::copy(samples, samples + n, ans.begin());

  SherpaOnnxCircularBufferFree(samples);
  return ans;
}

void CircularBuffer::Pop(int32_t n) const {
  SherpaOnnxCircularBufferPop(p_, n);
}

int32_t CircularBuffer::Size() const {
  return SherpaOnnxCircularBufferSize(p_);
}

int32_t CircularBuffer::Head() const {
  return SherpaOnnxCircularBufferHead(p_);
}

void CircularBuffer::Reset() const { SherpaOnnxCircularBufferReset(p_); }

VoiceActivityDetector VoiceActivityDetector::Create(
    const VadModelConfig &config, float buffer_size_in_seconds) {
  struct SherpaOnnxVadModelConfig c;
  memset(&c, 0, sizeof(c));

  c.silero_vad.model = config.silero_vad.model.c_str();
  c.silero_vad.threshold = config.silero_vad.threshold;
  c.silero_vad.min_silence_duration = config.silero_vad.min_silence_duration;
  c.silero_vad.min_speech_duration = config.silero_vad.min_speech_duration;
  c.silero_vad.window_size = config.silero_vad.window_size;
  c.silero_vad.max_speech_duration = config.silero_vad.max_speech_duration;

  c.ten_vad.model = config.ten_vad.model.c_str();
  c.ten_vad.threshold = config.ten_vad.threshold;
  c.ten_vad.min_silence_duration = config.ten_vad.min_silence_duration;
  c.ten_vad.min_speech_duration = config.ten_vad.min_speech_duration;
  c.ten_vad.window_size = config.ten_vad.window_size;
  c.ten_vad.max_speech_duration = config.ten_vad.max_speech_duration;

  c.sample_rate = config.sample_rate;
  c.num_threads = config.num_threads;
  c.provider = config.provider.c_str();
  c.debug = config.debug;

  auto p = SherpaOnnxCreateVoiceActivityDetector(&c, buffer_size_in_seconds);
  return VoiceActivityDetector(p);
}

VoiceActivityDetector::VoiceActivityDetector(
    const SherpaOnnxVoiceActivityDetector *p)
    : MoveOnly<VoiceActivityDetector, SherpaOnnxVoiceActivityDetector>(p) {}

void VoiceActivityDetector::Destroy(
    const SherpaOnnxVoiceActivityDetector *p) const {
  SherpaOnnxDestroyVoiceActivityDetector(p);
}

void VoiceActivityDetector::AcceptWaveform(const float *samples,
                                           int32_t n) const {
  SherpaOnnxVoiceActivityDetectorAcceptWaveform(p_, samples, n);
}

bool VoiceActivityDetector::IsEmpty() const {
  return SherpaOnnxVoiceActivityDetectorEmpty(p_);
}

bool VoiceActivityDetector ::IsDetected() const {
  return SherpaOnnxVoiceActivityDetectorDetected(p_);
}

void VoiceActivityDetector::Pop() const {
  SherpaOnnxVoiceActivityDetectorPop(p_);
}

void VoiceActivityDetector::Clear() const {
  SherpaOnnxVoiceActivityDetectorClear(p_);
}

SpeechSegment VoiceActivityDetector::Front() const {
  auto f = SherpaOnnxVoiceActivityDetectorFront(p_);

  SpeechSegment segment;
  if (!f) return segment;
  segment.start = f->start;
  segment.samples = std::vector<float>{f->samples, f->samples + f->n};

  SherpaOnnxDestroySpeechSegment(f);

  return segment;
}

std::shared_ptr<SpeechSegment> VoiceActivityDetector::FrontPtr() const {
  auto segment = Front();
  return std::make_shared<SpeechSegment>(segment);
}

void VoiceActivityDetector::Reset() const {
  SherpaOnnxVoiceActivityDetectorReset(p_);
}

void VoiceActivityDetector::Flush() const {
  SherpaOnnxVoiceActivityDetectorFlush(p_);
}

LinearResampler LinearResampler::Create(int32_t samp_rate_in_hz,
                                        int32_t samp_rate_out_hz,
                                        float filter_cutoff_hz,
                                        int32_t num_zeros) {
  auto p = SherpaOnnxCreateLinearResampler(samp_rate_in_hz, samp_rate_out_hz,
                                           filter_cutoff_hz, num_zeros);
  return LinearResampler(p);
}

LinearResampler::LinearResampler(const SherpaOnnxLinearResampler *p)
    : MoveOnly<LinearResampler, SherpaOnnxLinearResampler>(p) {}

void LinearResampler::Destroy(const SherpaOnnxLinearResampler *p) const {
  SherpaOnnxDestroyLinearResampler(p);
}

void LinearResampler::Reset() const { SherpaOnnxLinearResamplerReset(p_); }

std::vector<float> LinearResampler::Resample(const float *input,
                                             int32_t input_dim,
                                             bool flush) const {
  auto out = SherpaOnnxLinearResamplerResample(p_, input, input_dim, flush);
  if (!out) return {};

  std::vector<float> ans{out->samples, out->samples + out->n};

  SherpaOnnxLinearResamplerResampleFree(out);

  return ans;
}

int32_t LinearResampler::GetInputSamplingRate() const {
  return SherpaOnnxLinearResamplerResampleGetInputSampleRate(p_);
}

int32_t LinearResampler::GetOutputSamplingRate() const {
  return SherpaOnnxLinearResamplerResampleGetOutputSampleRate(p_);
}

std::string GetVersionStr() { return SherpaOnnxGetVersionStr(); }

std::string GetGitSha1() { return SherpaOnnxGetGitSha1(); }

std::string GetGitDate() { return SherpaOnnxGetGitDate(); }

std::string GetOnnxruntimeVersionStr() {
  return SherpaOnnxGetOnnxruntimeVersionStr();
}

bool FileExists(const std::string &filename) {
  return SherpaOnnxFileExists(filename.c_str());
}

// ============================================================
// For Offline Punctuation
// ============================================================
OfflinePunctuation OfflinePunctuation::Create(
    const OfflinePunctuationConfig &config) {
  struct SherpaOnnxOfflinePunctuationConfig c;
  memset(&c, 0, sizeof(c));
  c.model.ct_transformer = config.model.ct_transformer.c_str();
  c.model.num_threads = config.model.num_threads;
  c.model.debug = config.model.debug;
  c.model.provider = config.model.provider.c_str();

  const SherpaOnnxOfflinePunctuation *punct =
      SherpaOnnxCreateOfflinePunctuation(&c);
  return OfflinePunctuation(punct);
}

OfflinePunctuation::OfflinePunctuation(const SherpaOnnxOfflinePunctuation *p)
    : MoveOnly<OfflinePunctuation, SherpaOnnxOfflinePunctuation>(p) {}

void OfflinePunctuation::Destroy(const SherpaOnnxOfflinePunctuation *p) const {
  SherpaOnnxDestroyOfflinePunctuation(p);
}

std::string OfflinePunctuation::AddPunctuation(const std::string &text) const {
  const char *result = SherpaOfflinePunctuationAddPunct(p_, text.c_str());
  if (!result) return {};
  std::string ans(result);
  SherpaOfflinePunctuationFreeText(result);
  return ans;
}

// ============================================================
// For Online Punctuation
// ============================================================
OnlinePunctuation OnlinePunctuation::Create(
    const OnlinePunctuationConfig &config) {
  struct SherpaOnnxOnlinePunctuationConfig c;
  memset(&c, 0, sizeof(c));
  c.model.cnn_bilstm = config.model.cnn_bilstm.c_str();
  c.model.bpe_vocab = config.model.bpe_vocab.c_str();
  c.model.num_threads = config.model.num_threads;
  c.model.debug = config.model.debug;
  c.model.provider = config.model.provider.c_str();

  const SherpaOnnxOnlinePunctuation *punct =
      SherpaOnnxCreateOnlinePunctuation(&c);
  return OnlinePunctuation(punct);
}

OnlinePunctuation::OnlinePunctuation(const SherpaOnnxOnlinePunctuation *p)
    : MoveOnly<OnlinePunctuation, SherpaOnnxOnlinePunctuation>(p) {}

void OnlinePunctuation::Destroy(const SherpaOnnxOnlinePunctuation *p) const {
  SherpaOnnxDestroyOnlinePunctuation(p);
}

std::string OnlinePunctuation::AddPunctuation(const std::string &text) const {
  const char *result = SherpaOnnxOnlinePunctuationAddPunct(p_, text.c_str());
  if (!result) return {};
  std::string ans(result);
  SherpaOnnxOnlinePunctuationFreeText(result);
  return ans;
}

// ============================================================
// For Audio tagging
// ============================================================
AudioTagging AudioTagging::Create(const AudioTaggingConfig &config) {
  struct SherpaOnnxAudioTaggingConfig c;
  memset(&c, 0, sizeof(c));

  c.model.zipformer.model = config.model.zipformer.model.c_str();
  c.model.ced = config.model.ced.c_str();
  c.model.num_threads = config.model.num_threads;
  c.model.debug = config.model.debug;
  c.model.provider = config.model.provider.c_str();
  c.labels = config.labels.c_str();
  c.top_k = config.top_k;

  const SherpaOnnxAudioTagging *tagger = SherpaOnnxCreateAudioTagging(&c);
  return AudioTagging(tagger);
}

AudioTagging::AudioTagging(const SherpaOnnxAudioTagging *p)
    : MoveOnly<AudioTagging, SherpaOnnxAudioTagging>(p) {}

void AudioTagging::Destroy(const SherpaOnnxAudioTagging *p) const {
  SherpaOnnxDestroyAudioTagging(p);
}

OfflineStream AudioTagging::CreateStream() const {
  auto s = SherpaOnnxAudioTaggingCreateOfflineStream(p_);
  return OfflineStream{s};
}

std::vector<AudioEvent> AudioTagging::Compute(const OfflineStream *s,
                                              int32_t top_k /*= -1*/) {
  auto events = SherpaOnnxAudioTaggingCompute(p_, s->Get(), top_k);
  std::vector<AudioEvent> ans;

  auto pe = events;
  while (pe && *pe) {
    AudioEvent e;
    e.name = (*pe)->name;
    e.index = (*pe)->index;
    e.prob = (*pe)->prob;
    ans.push_back(std::move(e));
    ++pe;
  }

  SherpaOnnxAudioTaggingFreeResults(events);

  return ans;
}

std::shared_ptr<std::vector<AudioEvent>> AudioTagging::ComputePtr(
    const OfflineStream *s, int32_t top_k /*= -1*/) {
  auto events = Compute(s, top_k);
  return std::make_shared<std::vector<AudioEvent>>(events);
}

// ============================================================
// For Source Separation
// ============================================================

static void FillSourceSeparationModelConfig(
    const OfflineSourceSeparationModelConfig &src,
    SherpaOnnxOfflineSourceSeparationModelConfig *dst) {
  memset(dst, 0, sizeof(*dst));
  dst->spleeter.vocals = src.spleeter.vocals.c_str();
  dst->spleeter.accompaniment = src.spleeter.accompaniment.c_str();
  dst->uvr.model = src.uvr.model.c_str();
  dst->num_threads = src.num_threads;
  dst->provider = src.provider.c_str();
  dst->debug = src.debug;
}

OfflineSourceSeparation OfflineSourceSeparation::Create(
    const OfflineSourceSeparationConfig &config) {
  struct SherpaOnnxOfflineSourceSeparationConfig c;
  memset(&c, 0, sizeof(c));
  FillSourceSeparationModelConfig(config.model, &c.model);

  auto p = SherpaOnnxCreateOfflineSourceSeparation(&c);
  return OfflineSourceSeparation(p);
}

void OfflineSourceSeparation::Destroy(
    const SherpaOnnxOfflineSourceSeparation *p) const {
  SherpaOnnxDestroyOfflineSourceSeparation(p);
}

OfflineSourceSeparation::OfflineSourceSeparation(
    const SherpaOnnxOfflineSourceSeparation *p)
    : MoveOnly<OfflineSourceSeparation, SherpaOnnxOfflineSourceSeparation>(p) {}

SourceSeparationOutput OfflineSourceSeparation::Process(
    const float *const *samples, int32_t num_channels, int32_t num_samples,
    int32_t sample_rate) const {
  auto output = SherpaOnnxOfflineSourceSeparationProcess(
      p_, samples, num_channels, num_samples, sample_rate);
  if (output == nullptr) {
    return {};
  }

  SourceSeparationOutput ans;
  ans.sample_rate = output->sample_rate;
  ans.stems.resize(output->num_stems);
  for (int32_t s = 0; s < output->num_stems; ++s) {
    auto &stem = ans.stems[s];
    auto &c_stem = output->stems[s];
    stem.samples.resize(c_stem.num_channels);
    for (int32_t c = 0; c < c_stem.num_channels; ++c) {
      stem.samples[c] = {c_stem.samples[c], c_stem.samples[c] + c_stem.n};
    }
  }

  SherpaOnnxDestroySourceSeparationOutput(output);
  return ans;
}

int32_t OfflineSourceSeparation::GetOutputSampleRate() const {
  return SherpaOnnxOfflineSourceSeparationGetOutputSampleRate(p_);
}

int32_t OfflineSourceSeparation::GetNumberOfStems() const {
  return SherpaOnnxOfflineSourceSeparationGetNumberOfStems(p_);
}

// ============================================================================
// Spoken Language Identification
// ============================================================================

SpokenLanguageIdentification SpokenLanguageIdentification::Create(
    const SpokenLanguageIdentificationConfig &config) {
  struct SherpaOnnxSpokenLanguageIdentificationConfig c;
  memset(&c, 0, sizeof(c));
  c.whisper.encoder = config.whisper.encoder.c_str();
  c.whisper.decoder = config.whisper.decoder.c_str();
  c.whisper.tail_paddings = config.whisper.tail_paddings;
  c.num_threads = config.num_threads;
  c.debug = config.debug;
  c.provider = config.provider.c_str();

  const SherpaOnnxSpokenLanguageIdentification *p =
      SherpaOnnxCreateSpokenLanguageIdentification(&c);
  return SpokenLanguageIdentification(p);
}

SpokenLanguageIdentification::SpokenLanguageIdentification(
    const SherpaOnnxSpokenLanguageIdentification *p)
    : MoveOnly<SpokenLanguageIdentification,
               SherpaOnnxSpokenLanguageIdentification>(p) {}

void SpokenLanguageIdentification::Destroy(
    const SherpaOnnxSpokenLanguageIdentification *p) const {
  SherpaOnnxDestroySpokenLanguageIdentification(p);
}

OfflineStream SpokenLanguageIdentification::CreateStream() const {
  const SherpaOnnxOfflineStream *s =
      SherpaOnnxSpokenLanguageIdentificationCreateOfflineStream(p_);
  return OfflineStream(s);
}

SpokenLanguageIdentificationResult SpokenLanguageIdentification::Compute(
    const OfflineStream *s) const {
  const SherpaOnnxSpokenLanguageIdentificationResult *r =
      SherpaOnnxSpokenLanguageIdentificationCompute(p_, s->Get());
  SpokenLanguageIdentificationResult ans;
  if (r && r->lang) {
    ans.lang = r->lang;
  }
  SherpaOnnxDestroySpokenLanguageIdentificationResult(r);
  return ans;
}

// ============================================================================
// Speaker Embedding Extractor
// ============================================================================

SpeakerEmbeddingExtractor SpeakerEmbeddingExtractor::Create(
    const SpeakerEmbeddingExtractorConfig &config) {
  struct SherpaOnnxSpeakerEmbeddingExtractorConfig c;
  memset(&c, 0, sizeof(c));
  c.model = config.model.c_str();
  c.num_threads = config.num_threads;
  c.debug = config.debug;
  c.provider = config.provider.c_str();

  const SherpaOnnxSpeakerEmbeddingExtractor *p =
      SherpaOnnxCreateSpeakerEmbeddingExtractor(&c);
  return SpeakerEmbeddingExtractor(p);
}

SpeakerEmbeddingExtractor::SpeakerEmbeddingExtractor(
    const SherpaOnnxSpeakerEmbeddingExtractor *p)
    : MoveOnly<SpeakerEmbeddingExtractor,
               SherpaOnnxSpeakerEmbeddingExtractor>(p) {}

void SpeakerEmbeddingExtractor::Destroy(
    const SherpaOnnxSpeakerEmbeddingExtractor *p) const {
  SherpaOnnxDestroySpeakerEmbeddingExtractor(p);
}

int32_t SpeakerEmbeddingExtractor::Dim() const {
  return SherpaOnnxSpeakerEmbeddingExtractorDim(p_);
}

OnlineStream SpeakerEmbeddingExtractor::CreateStream() const {
  const SherpaOnnxOnlineStream *s =
      SherpaOnnxSpeakerEmbeddingExtractorCreateStream(p_);
  return OnlineStream(s);
}

bool SpeakerEmbeddingExtractor::IsReady(const OnlineStream *s) const {
  return SherpaOnnxSpeakerEmbeddingExtractorIsReady(p_, s->Get()) != 0;
}

std::vector<float> SpeakerEmbeddingExtractor::ComputeEmbedding(
    const OnlineStream *s) const {
  const float *v =
      SherpaOnnxSpeakerEmbeddingExtractorComputeEmbedding(p_, s->Get());
  if (!v) return {};
  int32_t dim = Dim();
  std::vector<float> ans(v, v + dim);
  SherpaOnnxSpeakerEmbeddingExtractorDestroyEmbedding(v);
  return ans;
}

// ============================================================================
// Speaker Embedding Manager
// ============================================================================

SpeakerEmbeddingManager SpeakerEmbeddingManager::Create(int32_t dim) {
  const SherpaOnnxSpeakerEmbeddingManager *p =
      SherpaOnnxCreateSpeakerEmbeddingManager(dim);
  return SpeakerEmbeddingManager(p);
}

SpeakerEmbeddingManager::SpeakerEmbeddingManager(
    const SherpaOnnxSpeakerEmbeddingManager *p)
    : MoveOnly<SpeakerEmbeddingManager, SherpaOnnxSpeakerEmbeddingManager>(p) {}

void SpeakerEmbeddingManager::Destroy(
    const SherpaOnnxSpeakerEmbeddingManager *p) const {
  SherpaOnnxDestroySpeakerEmbeddingManager(p);
}

bool SpeakerEmbeddingManager::Add(const std::string &name,
                                  const float *v) const {
  return SherpaOnnxSpeakerEmbeddingManagerAdd(p_, name.c_str(), v) != 0;
}

bool SpeakerEmbeddingManager::AddList(const std::string &name,
                                      const float **v) const {
  return SherpaOnnxSpeakerEmbeddingManagerAddList(p_, name.c_str(), v) != 0;
}

bool SpeakerEmbeddingManager::AddListFlattened(const std::string &name,
                                               const float *v,
                                               int32_t n) const {
  return SherpaOnnxSpeakerEmbeddingManagerAddListFlattened(p_, name.c_str(), v,
                                                           n) != 0;
}

bool SpeakerEmbeddingManager::Remove(const std::string &name) const {
  return SherpaOnnxSpeakerEmbeddingManagerRemove(p_, name.c_str()) != 0;
}

std::string SpeakerEmbeddingManager::Search(const float *v,
                                            float threshold) const {
  const char *name =
      SherpaOnnxSpeakerEmbeddingManagerSearch(p_, v, threshold);
  if (!name) return {};
  std::string ans(name);
  SherpaOnnxSpeakerEmbeddingManagerFreeSearch(name);
  return ans;
}

std::vector<SpeakerMatch> SpeakerEmbeddingManager::GetBestMatches(
    const float *v, float threshold, int32_t n) const {
  const SherpaOnnxSpeakerEmbeddingManagerBestMatchesResult *r =
      SherpaOnnxSpeakerEmbeddingManagerGetBestMatches(p_, v, threshold, n);
  std::vector<SpeakerMatch> ans;
  if (r) {
    for (int32_t i = 0; i < r->count; ++i) {
      SpeakerMatch m;
      m.score = r->matches[i].score;
      if (r->matches[i].name) m.name = r->matches[i].name;
      ans.push_back(std::move(m));
    }
    SherpaOnnxSpeakerEmbeddingManagerFreeBestMatches(r);
  }
  return ans;
}

bool SpeakerEmbeddingManager::Verify(const std::string &name, const float *v,
                                     float threshold) const {
  return SherpaOnnxSpeakerEmbeddingManagerVerify(p_, name.c_str(), v,
                                                 threshold) != 0;
}

bool SpeakerEmbeddingManager::Contains(const std::string &name) const {
  return SherpaOnnxSpeakerEmbeddingManagerContains(p_, name.c_str()) != 0;
}

int32_t SpeakerEmbeddingManager::NumSpeakers() const {
  return SherpaOnnxSpeakerEmbeddingManagerNumSpeakers(p_);
}

std::vector<std::string> SpeakerEmbeddingManager::GetAllSpeakers() const {
  const char *const *names =
      SherpaOnnxSpeakerEmbeddingManagerGetAllSpeakers(p_);
  std::vector<std::string> ans;
  if (names) {
    for (int32_t i = 0; names[i]; ++i) {
      ans.emplace_back(names[i]);
    }
    SherpaOnnxSpeakerEmbeddingManagerFreeAllSpeakers(names);
  }
  return ans;
}

// ============================================================================
// Offline Speaker Diarization
// ============================================================================

static int32_t DiarizationProgressCallback(int32_t num_processed_chunks,
                                           int32_t num_total_chunks,
                                           void *arg) {
  auto *cb = static_cast<OfflineSpeakerDiarizationProgressCallback *>(arg);
  (*cb)(num_processed_chunks, num_total_chunks);
  return 0;
}

OfflineSpeakerDiarization OfflineSpeakerDiarization::Create(
    const OfflineSpeakerDiarizationConfig &config) {
  struct SherpaOnnxOfflineSpeakerDiarizationConfig c;
  memset(&c, 0, sizeof(c));
  c.segmentation.pyannote.model =
      config.segmentation.pyannote.model.c_str();
  c.segmentation.pyannote.window_shift_ratio =
      config.segmentation.pyannote.window_shift_ratio;
  c.segmentation.num_threads = config.segmentation.num_threads;
  c.segmentation.debug = config.segmentation.debug;
  c.segmentation.provider = config.segmentation.provider.c_str();
  c.embedding.model = config.embedding.model.c_str();
  c.embedding.num_threads = config.embedding.num_threads;
  c.embedding.debug = config.embedding.debug;
  c.embedding.provider = config.embedding.provider.c_str();
  c.clustering.num_clusters = config.clustering.num_clusters;
  c.clustering.threshold = config.clustering.threshold;
  c.clustering.compute_confidence = config.clustering.compute_confidence ? 1 : 0;
  c.min_duration_on = config.min_duration_on;
  c.min_duration_off = config.min_duration_off;

  const SherpaOnnxOfflineSpeakerDiarization *p =
      SherpaOnnxCreateOfflineSpeakerDiarization(&c);
  return OfflineSpeakerDiarization(p);
}

OfflineSpeakerDiarization::OfflineSpeakerDiarization(
    const SherpaOnnxOfflineSpeakerDiarization *p)
    : MoveOnly<OfflineSpeakerDiarization,
               SherpaOnnxOfflineSpeakerDiarization>(p) {}

void OfflineSpeakerDiarization::Destroy(
    const SherpaOnnxOfflineSpeakerDiarization *p) const {
  SherpaOnnxDestroyOfflineSpeakerDiarization(p);
}

int32_t OfflineSpeakerDiarization::GetSampleRate() const {
  return SherpaOnnxOfflineSpeakerDiarizationGetSampleRate(p_);
}

void OfflineSpeakerDiarization::SetConfig(
    const OfflineSpeakerDiarizationConfig &config) const {
  struct SherpaOnnxOfflineSpeakerDiarizationConfig c;
  memset(&c, 0, sizeof(c));
  c.clustering.num_clusters = config.clustering.num_clusters;
  c.clustering.threshold = config.clustering.threshold;
  c.clustering.compute_confidence = config.clustering.compute_confidence ? 1 : 0;
  SherpaOnnxOfflineSpeakerDiarizationSetConfig(p_, &c);
}

static std::vector<OfflineSpeakerDiarizationSegment> CollectSegments(
    const SherpaOnnxOfflineSpeakerDiarizationResult *r) {
  std::vector<OfflineSpeakerDiarizationSegment> ans;
  if (!r) {
    return ans;
  }
  int32_t num_segments =
      SherpaOnnxOfflineSpeakerDiarizationResultGetNumSegments(r);
  const SherpaOnnxOfflineSpeakerDiarizationSegment *segments =
      SherpaOnnxOfflineSpeakerDiarizationResultSortByStartTime(r);
  for (int32_t i = 0; i < num_segments; ++i) {
    OfflineSpeakerDiarizationSegment seg;
    seg.start = segments[i].start;
    seg.end = segments[i].end;
    seg.speaker = segments[i].speaker;
    seg.confidence = segments[i].confidence;
    ans.push_back(seg);
  }
  SherpaOnnxOfflineSpeakerDiarizationDestroySegment(segments);
  return ans;
}

std::vector<OfflineSpeakerDiarizationSegment>
OfflineSpeakerDiarization::Process(const float *samples, int32_t n) const {
  const SherpaOnnxOfflineSpeakerDiarizationResult *r =
      SherpaOnnxOfflineSpeakerDiarizationProcess(p_, samples, n);
  auto ans = CollectSegments(r);
  if (r) {
    SherpaOnnxOfflineSpeakerDiarizationDestroyResult(r);
  }
  return ans;
}

std::vector<OfflineSpeakerDiarizationSegment>
OfflineSpeakerDiarization::Process(
    const float *samples, int32_t n,
    const OfflineSpeakerDiarizationProgressCallback &callback) const {
  if (!callback) {
    return Process(samples, n);
  }
  OfflineSpeakerDiarizationProgressCallback cb = callback;
  const SherpaOnnxOfflineSpeakerDiarizationResult *r =
      SherpaOnnxOfflineSpeakerDiarizationProcessWithCallback(
          p_, samples, n, DiarizationProgressCallback, &cb);
  auto ans = CollectSegments(r);
  if (r) {
    SherpaOnnxOfflineSpeakerDiarizationDestroyResult(r);
  }
  return ans;
}

// ============================================================
// For Offline Diacritization
// ============================================================
OfflineDiacritization OfflineDiacritization::Create(
    const OfflineDiacritizationConfig &config) {
  struct SherpaOnnxOfflineDiacritizationConfig c;
  memset(&c, 0, sizeof(c));
  c.model.catt_encoder = config.model.catt_encoder.c_str();
  c.model.catt_decoder = config.model.catt_decoder.c_str();
  c.model.num_threads = config.model.num_threads;
  c.model.debug = config.model.debug;
  c.model.provider = config.model.provider.c_str();

  const SherpaOnnxOfflineDiacritization *diacrt =
      SherpaOnnxCreateOfflineDiacritization(&c);
  return OfflineDiacritization(diacrt);
}

OfflineDiacritization::OfflineDiacritization(const SherpaOnnxOfflineDiacritization *diacrt)
    : MoveOnly<OfflineDiacritization, SherpaOnnxOfflineDiacritization>(diacrt) {}

void OfflineDiacritization::Destroy(const SherpaOnnxOfflineDiacritization *diacrt) const {
  SherpaOnnxDestroyOfflineDiacritization(diacrt);
}

std::string OfflineDiacritization::AddDiacritics(const std::string &text) const {
  const char *result = SherpaOfflineDiacritizationAddDiacritics(p_, text.c_str());
  if (!result) return {};
  std::string ans(result);
  SherpaOfflineDiacritizationFreeText(result);
  return ans;
}

}  // namespace sherpa_onnx::cxx
